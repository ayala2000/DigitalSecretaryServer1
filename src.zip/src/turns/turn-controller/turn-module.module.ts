import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { TurnSchema } from '../turn.schema';
import { TurnsService } from '../turn-service/turn-service.service';
import { TurnController } from './turn-controller.controller';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'Turn', schema: TurnSchema }]),
  ],
  providers: [TurnsService],
  controllers: [TurnController],
  exports: [TurnsService],
})
export class TurnModule {}
