import { Injectable, UnauthorizedException } from '@nestjs/common';
import { Db, MongoClient } from 'mongodb';
import { Turn } from '../Turn.inerface';
//import * as bcrypt from 'bcrypt';
import { error, log } from 'console';
//import { turnType } from '../../typesOfTurn/turnType';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { CreateTurnDto } from '../create-turn.dto';


@Injectable()
export class TurnsService {


  constructor(@InjectModel('Turn') private readonly turnModel: Model<Turn>) { }


  // async connectToDatabase(): Promise<MongoClient> {
  //   const client = await MongoClient.connect('mongodb://127.0.0.1:27017/Users');
  //   this.db = client.db('Users');
  //   console.log('Connected to turn');

  //   return client;
  // }
  async getByDate(date: Date): Promise<Turn[] | undefined> {
    const m = this.turnModel.find({ date }).exec();
    return m;
  }

  async getAll(): Promise<Turn[] | undefined> {
    const arr = this.turnModel.find().exec();
    return arr;
  }
  //async function that creating object- new record of turns tables.
  // async addTreatment(createTreatmentDto: CreateTurnDto): Promise<Turn> {
  //   const createdTreatment = new this.turnModel(createTreatmentDto);
  //   return createdTreatment.save();
  // }

  async create(createTurnDto: CreateTurnDto): Promise<Turn> {
    const createdTurn = new this.turnModel(createTurnDto);
    return createdTurn.save();
  }

  async remove(id: string): Promise<Turn> {
    return this.turnModel.findByIdAndRemove(id).exec();
  }

  async update(id: string, updateUserDto: any): Promise<Turn> {
    return this.turnModel.findByIdAndUpdate(id, updateUserDto, { new: true }).exec();
  }



  async getAvailableDates(duration: any): Promise<Date[]> {
    const currentDate = new Date();
    const sixMonthsFromNow = new Date();
    sixMonthsFromNow.setMonth(currentDate.getMonth() + 1);

    const datesInTable = await this.turnModel.distinct('date', {
      date: {
        $gte: currentDate,
        $lt: sixMonthsFromNow,
      },
    });
    console.log("datesInTable", datesInTable)

    const allDates = [];
    const allTimes = [];

    for (
      let date = new Date(currentDate);
      date < sixMonthsFromNow;
      date.setDate(date.getDate() + 1)) {

      const isInTable = datesInTable.some(
        (tableDate) => tableDate.getDate() === date.getDate(),
      );

      if (!isInTable) {
        allDates.push(new Date(date));
      }

      else {
        allTimes.push(new Date(date))
      }
    }
    console.log("allDates", allDates)
    return allDates;
  }

  async getFreeQueues(date: Date, queueDuration: number): Promise<any[]> {
    console.log("arry");

    const openingTime = new Date(date).setUTCHours(10, 0, 0); // Set the opening time to 10:00
    const closingTime = new Date(date).setUTCHours(16, 0, 0); // Set the closing time to 16:00
    const closingDate = new Date(closingTime);
    console.log("closingDate", closingDate)
    const duration = new Date().setMinutes(queueDuration);

    console.log(duration);
    //מערך המכיל את כל התורים שבתאריך הנוכחי
    const occupiedQueues = await this.turnModel.find({
      date: { $eq: date },
    });
    console.log(occupiedQueues);



    const freeQueues = [];
    let currentTime = new Date(openingTime);//check if time empty
    const localOffset = currentTime.getTimezoneOffset();

    // Calculate the local date by adding the offset to the UTC date
    const localDate = new Date(currentTime.getTime() + (localOffset * 60 * 1000));

    // Now you can work with the local date
    console.log(localDate);
    console.log("currentTime", currentTime)
    console.log("queueDuration", queueDuration);//duration
    while (currentTime < closingDate) {
      console.log("cur", currentTime, currentTime.getMinutes());
      let endTime2 = new Date(currentTime);
      console.log("endTime2", endTime2);
      let Duration = parseInt(queueDuration.toString());
      endTime2.setMinutes(
        currentTime.getMinutes() + Duration);
      console.log("endTime2", endTime2);

      const endTime = new Date(endTime2);
      console.log(endTime, 'endTime');

      //console.log(closingTime, 'endTime');



      if (!occupiedQueues.some((queue) =>
        new Date(queue.time).getTime() <= currentTime.getTime() &&
        new Date(queue.time).getTime() >= endTime2.getTime(),
      )) {

        freeQueues.push(currentTime);


      }
      console.log(freeQueues, 'freeQueues');

      currentTime = endTime2;
    }

    return freeQueues;
  }
}





  // async update(_id: object, newturn: any) {
  //   try {
  //     const df = await this.findById(_id);
  //     console.log(df);
  //     await this.db.collection<Turn>('Turn').findOneAndUpdate({ _id }, {$set: newturn});
  //     console.log('sucsses update turn');
  //   } catch (error){
  //     console.error('error update turn', error);
  //   }
  // }


