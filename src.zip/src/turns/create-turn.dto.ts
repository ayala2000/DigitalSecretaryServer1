
import { TurnType } from "../typesOfTurn/turnType.interface";
//import moment from 'moment';
export class CreateTurnDto {
    email: string;
    name: string;
    date: Date;
    time:string;
    typeOfTurn: String;
}
 
//moment().set({ hours: 10, minutes: 30 })