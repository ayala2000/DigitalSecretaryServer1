
export interface TurnType{
    typeOfTurn:string;
    duration:number;
    ManagerTurnID:String;
}