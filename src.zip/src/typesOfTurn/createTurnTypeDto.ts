export class CreateTurnTypeDto{
    
    typeOfTurn:string;
    duration:number;
    ManagerTurnID:object;
    
}