import { Injectable } from '@nestjs/common';

@Injectable()
export class DateService {
    // getDayOfWeek(date: Date): string {
    //     const options = { weekday: 'long' };
    //     const dayOfWeek = date.toLocaleDateString('en-US', options);
    //     return dayOfWeek;
    //   }
}
