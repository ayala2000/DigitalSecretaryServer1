
export class CreateActivityTimeDto {
   name: string;
   daysOfWeek: number[];
   startHoure: string;
   endHoure: string;
  }