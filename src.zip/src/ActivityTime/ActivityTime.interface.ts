
export interface ActivityTime {
    name: string;
    daysOfWeek: number[];
    startHoure: string;
    endHoure: string;
    
  }